import React, { useEffect, useState } from 'react';
import {
    Container,
    TextField,
    Grid,
    Card,
    CardContent,
    CardActions,
    Typography,
    Button,
    Box,
    CircularProgress,
    Alert,
    useTheme
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { useDispatch, useSelector } from 'react-redux';
import CreateRideModal from '../components/modals/CreateRideModal';
import {
    getAvailableRidesRequest,
    getAvailableRidesDataSelector,
    getAvailableRidesLoadingSelector,
    getAvailableRidesErrorSelector
} from '../infrastructure/redux/taxi/getAvailable/slice';
import {
    addRideRequest,
    addRideLoadingSelector
} from '../infrastructure/redux/taxi/add/slice';
import {
    joinRideRequest,
    joinRideLoadingSelector,
    joinRideSuccessSelector
} from '../infrastructure/redux/taxi/join/slice';

const StyledCard = styled(Card)(({ theme }) => ({
    borderRadius: theme.shape.borderRadius * 2,
    border: `2px solid ${theme.palette.mode === 'dark' ? theme.palette.grey[800] : theme.palette.grey[300]}`,
    backgroundColor: theme.palette.background.paper,
    boxShadow: 'none',
    transition: 'box-shadow 0.2s',
    '&:hover': {
        boxShadow:
            theme.palette.mode === 'dark'
                ? '0 4px 24px 0 rgba(0,0,0,0.50)'
                : '0 4px 18px 0 rgba(30,30,30,0.07)'
    }
}));

const StyledTextField = styled(TextField)(({ theme }) => ({
    '& .MuiInputBase-root': {
        backgroundColor: theme.palette.mode === 'dark'
            ? theme.palette.grey[900]
            : theme.palette.grey[50],
        borderRadius: theme.shape.borderRadius * 1.5,
    },
    '& .MuiOutlinedInput-notchedOutline': {
        borderColor: theme.palette.mode === 'dark'
            ? theme.palette.grey[700]
            : theme.palette.grey[300],
    },
    '&:hover .MuiOutlinedInput-notchedOutline': {
        borderColor: theme.palette.mode === 'dark'
            ? theme.palette.grey[500]
            : theme.palette.grey[800],
    },
}));

const StyledButton = styled(Button)(({ theme }) => ({
    borderRadius: theme.shape.borderRadius * 1.5,
    backgroundColor: theme.palette.mode === 'dark'
        ? theme.palette.common.white
        : theme.palette.common.black,
    color: theme.palette.mode === 'dark'
        ? theme.palette.common.black
        : theme.palette.common.white,
    fontWeight: 600,
    letterSpacing: 1,
    textTransform: 'none',
    '&:hover': {
        backgroundColor: theme.palette.mode === 'dark'
            ? theme.palette.grey[300]
            : theme.palette.grey[900],
        color: theme.palette.mode === 'dark'
            ? theme.palette.common.black
            : theme.palette.common.white,
    },
}));

export default function TaxiListPage() {
    const dispatch = useDispatch();
    const theme = useTheme();
    const profile = useSelector(state => state.user.profile);
    const rides = useSelector(getAvailableRidesDataSelector);
    const loading = useSelector(getAvailableRidesLoadingSelector);
    const error = useSelector(getAvailableRidesErrorSelector);
    const addLoading = useSelector(addRideLoadingSelector);
    const joinLoading = useSelector(joinRideLoadingSelector);
    const joinSuccess = useSelector(joinRideSuccessSelector);

    const [searchTo, setSearchTo] = useState('');
    const [openCreateModal, setOpenCreateModal] = useState(false);

    useEffect(() => {
        dispatch(getAvailableRidesRequest());
    }, [dispatch, joinSuccess]);

    const filteredRides = rides.filter(ride =>
        ride.toLocation.toLowerCase().includes(searchTo.toLowerCase())
    );

    const handleCreateRide = (form) => {
        dispatch(addRideRequest(form));
        setOpenCreateModal(false);
    };

    const handleJoin = (rideId) => {
        dispatch(joinRideRequest(rideId));
    };

    return (
        <Container
            maxWidth="lg"
            sx={{
                py: 4,
                backgroundColor: theme.palette.background.default,
                color: theme.palette.text.primary,
            }}
        >
            <Box sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                mb: 3,
            }}>
                <Typography
                    variant="h4"
                    sx={{
                        fontWeight: 700,
                        color: theme.palette.text.primary,
                        letterSpacing: 1,
                    }}
                >
                    Taxi Rides
                </Typography>
                <StyledButton onClick={() => setOpenCreateModal(true)}>
                    Создать поездку
                </StyledButton>
            </Box>
            <CreateRideModal
                open={openCreateModal}
                onClose={() => setOpenCreateModal(false)}
                onSubmit={handleCreateRide}
                loading={addLoading}
            />

            <Box sx={{ mb: 3 }}>
                <StyledTextField
                    label="Поиск по пункту назначения"
                    placeholder="Введите пункт Б"
                    variant="outlined"
                    fullWidth
                    value={searchTo}
                    onChange={e => setSearchTo(e.target.value)}
                />
            </Box>

            {loading && (
                <Box display="flex" justifyContent="center" py={4}>
                    <CircularProgress />
                </Box>
            )}
            {error && (
                <Alert severity="error" sx={{ my: 2 }}>
                    {error}
                </Alert>
            )}

            <Grid container spacing={3}>
                {filteredRides.map(ride => (
                    <Grid item xs={12} sm={6} md={4} key={ride.id}>
                        <StyledCard>
                            <CardContent sx={{ flexGrow: 1 }}>
                                <Typography
                                    variant="h6"
                                    gutterBottom
                                    sx={{
                                        fontWeight: 700,
                                        color: theme.palette.mode === 'dark'
                                            ? theme.palette.grey[100]
                                            : theme.palette.grey[900],
                                    }}
                                >
                                    {ride.carModel}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                    <b>Откуда:</b> {ride.fromLocation}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                    <b>Куда:</b> {ride.toLocation}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                    <b>Время:</b>{' '}
                                    {new Date(ride.startTime).toLocaleString()}
                                </Typography>
                                <Typography variant="body2" sx={{ mb: 0.5 }}>
                                    <b>Цена:</b> ${Number(ride.price).toFixed(2)}
                                </Typography>
                                <Typography variant="body2">
                                    <b>Свободно мест:</b> {ride.seatsAvailable}
                                </Typography>
                            </CardContent>
                            <CardActions sx={{ justifyContent: 'flex-end', p: 2 }}>
                                <StyledButton
                                    variant="contained"
                                    size="small"
                                    onClick={() => handleJoin(ride.id)}
                                    disabled={joinLoading || profile?.id === ride.userId}
                                    sx={{ fontSize: 15, minWidth: 130 }}
                                >
                                    Зарегистрироваться
                                </StyledButton>
                            </CardActions>
                        </StyledCard>
                    </Grid>
                ))}
                {filteredRides.length === 0 && !loading && (
                    <Grid item xs={12}>
                        <Typography color="text.secondary" align="center" sx={{ mt: 4 }}>
                            Нет доступных поездок
                        </Typography>
                    </Grid>
                )}
            </Grid>
        </Container>
    );
}
